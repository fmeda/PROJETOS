# SentinelCore-Backup

Automatiza backups seguros para ambientes híbridos com Zabbix, Grafana, Graylog e pfSense.