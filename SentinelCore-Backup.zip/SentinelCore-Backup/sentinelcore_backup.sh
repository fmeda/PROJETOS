#!/bin/bash
# SentinelCore-Backup script principal (v2.0)
echo "Executando SentinelCore..."