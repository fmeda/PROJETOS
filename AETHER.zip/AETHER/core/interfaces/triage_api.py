from fastapi import FastAPI
from modules.alert_triage import triage_service
from modules.alert_triage.db import init_db

app = FastAPI(title="AETHER Triage API")

@app.on_event("startup")
def startup_event():
    init_db()

@app.post("/api/triagem")
async def triagem_alerta(alert: dict):
    result = triage_service.classify_alert(alert)
    return result
