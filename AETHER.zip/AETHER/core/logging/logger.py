import logging
from logging.handlers import RotatingFileHandler
import os

LOG_DIR = "/var/log/aether"
LOG_FILE = "aether.log"
MAX_BYTES = 10 * 1024 * 1024  # 10 MB
BACKUP_COUNT = 5

if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

logger = logging.getLogger("aether_logger")
logger.setLevel(logging.INFO)

handler = RotatingFileHandler(os.path.join(LOG_DIR, LOG_FILE), maxBytes=MAX_BYTES, backupCount=BACKUP_COUNT)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)

logger.addHandler(handler)

def log_info(message: str):
    logger.info(message)

def log_error(message: str):
    logger.error(message)
