from sklearn.ensemble import IsolationForest
import numpy as np

class UebaEngine:
    def __init__(self):
        # Inicializa o modelo Isolation Forest para detecção de anomalias
        self.model = IsolationForest(contamination=0.01, random_state=42)
        self.fitted = False

    def train(self, features: np.ndarray):
        """
        Treina o modelo com dados de features.
        :param features: np.ndarray com dados para treino
        """
        self.model.fit(features)
        self.fitted = True

    def predict(self, features: np.ndarray):
        """
        Prediz se as amostras são normais ou anômalas.
        :param features: np.ndarray com dados para previsão
        :return: lista com labels -1 (anômalo) ou 1 (normal)
        """
        if not self.fitted:
            raise Exception("Modelo não treinado ainda.")
        return self.model.predict(features)

    def extract_features(self, logs):
        """
        Exemplo simples: extrai features numéricas de logs para análise.
        :param logs: lista de strings (logs)
        :return: np.ndarray com features (exemplo simples)
        """
        # Aqui, como exemplo, retornamos comprimento do log e número de dígitos
        features = []
        for log in logs:
            length = len(log)
            digits = sum(c.isdigit() for c in log)
            features.append([length, digits])
        return np.array(features)
