import React, { useState } from "react";
import { enviarAlerta } from "../api";

function Dashboard() {
  const [mensagem, setMensagem] = useState("");
  const [origem, setOrigem] = useState("");
  const [resultado, setResultado] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await enviarAlerta(mensagem, origem);
    setResultado(res);
  };

  return (
    <div style={{ padding: "2rem" }}>
      <form onSubmit={handleSubmit}>
        <label>
          Mensagem do Alerta:
          <input type="text" value={mensagem} onChange={e => setMensagem(e.target.value)} style={{ width: "100%" }} />
        </label>
        <br />
        <label>
          Origem:
          <input type="text" value={origem} onChange={e => setOrigem(e.target.value)} style={{ width: "100%" }} />
        </label>
        <br />
        <button type="submit">Enviar para Triagem</button>
      </form>

      {resultado && (
        <div style={{ marginTop: "2rem" }}>
          <h3>Resultado:</h3>
          <p><strong>Classificação:</strong> {resultado.classificacao}</p>
          <p><strong>Recomendação:</strong> {resultado.recomendacao}</p>
        </div>
      )}
    </div>
  );
}

export default Dashboard;
