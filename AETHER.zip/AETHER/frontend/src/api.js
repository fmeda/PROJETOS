import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:8080",
});

export const enviarAlerta = async (mensagem, origem) => {
  const payload = {
    mensagem,
    origem
  };
  const response = await API.post("/api/triagem", payload);
  return response.data;
};
