# AETHER: AI-Powered Cyber Defense Toolkit

## Descrição
AETHER é uma suíte de segurança ofensiva e defensiva baseada em Inteligência Artificial para análise comportamental (UEBA), triagem de alertas, classificação de logs, geração de playbooks, hardening automatizado e resposta adaptativa.

## Componentes
- API RESTful (FastAPI) para detecção e triagem de eventos
- Classificação de alertas com IA (scikit-learn)
- Geração de logs e histórico em SQLite
- Frontend React (dashboard em desenvolvimento)
- Scripts de automação, segurança e CI/CD

## Execução
```bash
bash setup.sh
