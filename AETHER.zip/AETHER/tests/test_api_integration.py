from fastapi.testclient import TestClient
from core.interfaces.triage_api import app

client = TestClient(app)

def test_triagem_endpoint():
    response = client.post("/api/triagem", json={
        "mensagem": "Falha de login no sistema",
        "origem": "192.168.0.99"
    })
    assert response.status_code == 200
    data = response.json()
    assert "classificacao" in data
    assert "recomendacao" in data
