from modules.ueba_engine.service import UebaEngine
import numpy as np

def test_ueba_basic_detection():
    engine = UebaEngine()
    logs = [
        "SSH login failed from 192.168.0.1",
        "User admin changed password",
        "Multiple failed logins from 10.0.0.5"
    ]
    features = engine.extract_features(logs)
    engine.train(features)
    results = engine.predict(features)
    assert len(results) == len(logs)
    assert all(res in [-1, 1] for res in results)
