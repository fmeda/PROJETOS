import sys
from modules.ueba_engine.service import UebaEngine

def main():
    engine = UebaEngine()
    # Exemplo: receber logs da entrada padrão
    logs = sys.stdin.read().splitlines()
    features = engine.extract_features(logs)
    engine.train(features)
    predictions = engine.predict(features)

    for log, pred in zip(logs, predictions):
        status = "ANÔMALO" if pred == -1 else "NORMAL"
        print(f"{status}: {log}")

if __name__ == "__main__":
    main()
