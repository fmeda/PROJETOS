import sqlite3
import os

DB_PATH = "aether_alerts.db"

def init_db():
    """
    Inicializa o banco de dados SQLite para armazenar alertas.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS alertas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            origem TEXT,
            classificacao TEXT,
            detalhes TEXT
        )
    ''')
    conn.commit()
    conn.close()

def insert_alert(timestamp, origem, classificacao, detalhes):
    """
    Insere um alerta classificado no banco de dados.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO alertas (timestamp, origem, classificacao, detalhes) VALUES (?, ?, ?, ?)",
        (timestamp, origem, classificacao, detalhes)
    )
    conn.commit()
    conn.close()
