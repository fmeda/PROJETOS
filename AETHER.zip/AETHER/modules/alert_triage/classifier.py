import joblib
from sklearn.ensemble import RandomForestClassifier
import numpy as np
import os

MODEL_PATH = "scripts/ml_models/alert_classifier.joblib"

def train_dummy_classifier():
    """
    Treina um classificador dummy para fins de teste com scikit-learn.
    """
    X = np.array([[10, 1], [30, 2], [100, 5]])
    y = ["Informativo", "Importante", "Crítico"]
    model = RandomForestClassifier()
    model.fit(X, y)
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    return model

def load_classifier():
    """
    Carrega o modelo de classificação salvo. Treina se não existir.
    """
    if not os.path.exists(MODEL_PATH):
        return train_dummy_classifier()
    return joblib.load(MODEL_PATH)
