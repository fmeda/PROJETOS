from modules.alert_triage.classifier import load_classifier
from modules.alert_triage.db import insert_alert
from datetime import datetime
import numpy as np

clf = load_classifier()

def classify_alert(alert_data):
    """
    Classifica um alerta com base em características da mensagem.
    """
    msg = alert_data.get("mensagem", "")
    origem = alert_data.get("origem", "desconhecida")
    features = np.array([[len(msg), len(msg.split())]])
    pred = clf.predict(features)[0]

    # Armazena alerta
    insert_alert(
        timestamp=datetime.utcnow().isoformat(),
        origem=origem,
        classificacao=pred,
        detalhes=msg
    )

    return {
        "classificacao": pred,
        "recomendacao": "Verificar imediatamente." if pred == "Crítico" else "Monitorar"
    }
