# Pacote para geração de scripts de hardening via GPT
