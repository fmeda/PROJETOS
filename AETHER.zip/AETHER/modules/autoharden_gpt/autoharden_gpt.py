def generate_hardening_playbook(system_info):
    """
    Placeholder para geração automática de playbooks Ansible via GPT.
    :param system_info: dict com informações do sistema alvo
    :return: str com playbook Ansible em YAML
    """
    # Exemplo simplificado: retornar um playbook hardcoded
    playbook = f"""
- name: Hardening básico para {system_info.get('hostname', 'sistema')}
  hosts: all
  become: yes
  tasks:
    - name: Atualizar pacotes
      apt:
        upgrade: dist
        update_cache: yes

    - name: Desabilitar root login SSH
      lineinfile:
        path: /etc/ssh/sshd_config
        regexp: '^PermitRootLogin'
        line: 'PermitRootLogin no'

    - name: Reiniciar ssh
      service:
        name: ssh
        state: restarted
"""
    return playbook
