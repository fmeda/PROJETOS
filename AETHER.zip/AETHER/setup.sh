#!/bin/bash

echo "[+] Iniciando setup do AETHER..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

echo "[+] Rodando testes e verificações..."
pytest tests/
bandit -r modules/ core/
mypy modules/ core/

echo "[+] Iniciando aplicação..."
uvicorn core.interfaces.triage_api:app --host 0.0.0.0 --port 8080 --reload
