#!/usr/bin/env python3
import os
import subprocess
import argparse
import datetime
import socket
import shutil
import platform
import importlib.util
from termcolor import colored

REPORT = []

def log_result(message, status):
    color_map = {"success": "green", "fail": "red", "check": "yellow"}
    symbols = {"success": "[✔]", "fail": "[✖]", "check": "[!]"}
    print(colored(f"{symbols[status]} {message}", color_map[status]))
    REPORT.append(f"[{status.upper()}] {message}")

def check_root():
    if platform.system() != "Linux":
        log_result("Este instalador foi projetado para Linux.", "fail")
        return False
    if os.geteuid() != 0:
        log_result("Este script precisa ser executado como root.", "fail")
        return False
    log_result("Verificação de root: OK.", "success")
    return True

def check_internet(timeout=3):
    hosts = ["8.8.8.8", "1.1.1.1", "google.com"]
    for host in hosts:
        try:
            socket.setdefaulttimeout(timeout)
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((host, 53))
            sock.close()
            log_result(f"Conexão com internet via {host}: OK.", "success")
            return True
        except Exception:
            continue
    log_result("Falha ao conectar na internet.", "fail")
    return False

def check_command_exists(command):
    exists = shutil.which(command) is not None
    if exists:
        log_result(f"Comando '{command}' encontrado.", "success")
    else:
        log_result(f"Comando '{command}' não encontrado.", "fail")
    return exists

def check_python_module(module_name):
    if importlib.util.find_spec(module_name) is not None:
        log_result(f"Módulo Python '{module_name}' disponível.", "success")
        return True
    else:
        log_result(f"Módulo Python '{module_name}' ausente. Instale com: pip install {module_name}", "fail")
        return False

def run_command(command, success_msg, fail_msg):
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            log_result(success_msg, "success")
            REPORT.append(f"Output: {result.stdout.strip()}")
            return True, result.stdout
        else:
            log_result(f"{fail_msg} - {result.stderr.strip()}", "fail")
            REPORT.append(f"Erro: {result.stderr.strip()}")
            return False, result.stderr
    except Exception as e:
        log_result(f"{fail_msg} - Exception: {str(e)}", "fail")
        REPORT.append(f"Exception: {str(e)}")
        return False, str(e)

def confirm(prompt):
    while True:
        answer = input(f"{prompt} (s/n): ").lower()
        if answer in ('s', 'n'):
            return answer == 's'
        print("Por favor, responda 's' ou 'n'.")

def run_prerequisites_checks():
    checks = [
        check_root,
        check_internet,
        lambda: check_command_exists("curl"),
        lambda: check_command_exists("apt-get"),
        lambda: check_python_module("termcolor")
    ]
    results = [check() for check in checks]
    return all(results)

def install_pihole():
    if not confirm("Deseja instalar o Pi-hole?"):
        log_result("Instalação do Pi-hole pulada.", "check")
        return
    log_result("Instalando Pi-hole...", "check")
    run_command("curl -sSL https://install.pi-hole.net | bash", 
                "Pi-hole instalado com sucesso.", 
                "Falha na instalação do Pi-hole.")

def install_suricata():
    if not confirm("Deseja instalar o Suricata?"):
        log_result("Instalação do Suricata pulada.", "check")
        return
    log_result("Instalando Suricata...", "check")
    run_command("apt-get update && apt-get install -y suricata",
                "Suricata instalado com sucesso.",
                "Falha na instalação do Suricata.")

def install_wazuh_agent():
    if not confirm("Deseja instalar o Wazuh Agent?"):
        log_result("Instalação do Wazuh Agent pulada.", "check")
        return
    log_result("Instalando Wazuh Agent...", "check")
    run_command("curl -s https://packages.wazuh.com/4.6/wazuh-install.sh | bash -s -- -a",
                "Wazuh Agent instalado com sucesso.",
                "Falha na instalação do Wazuh Agent.")

def install_kibana():
    if not confirm("Deseja instalar o Kibana?"):
        log_result("Instalação do Kibana pulada.", "check")
        return
    log_result("Instalando Kibana (Elastic Stack)...", "check")
    run_command("apt-get install -y kibana",
                "Kibana instalado com sucesso.",
                "Falha na instalação do Kibana.")

def save_report():
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    path = f"reports/installation_report_{timestamp}.txt"
    os.makedirs("reports", exist_ok=True)
    with open(path, "w") as f:
        f.write("\n".join(REPORT))
    print(colored(f"\n[✓] Relatório salvo em {path}", "cyan"))

def main():
    parser = argparse.ArgumentParser(description="Instalador SOC Lite - Pré-checagem e instalação local")
    parser.add_argument("--local", action="store_true", help="Executa instalação localmente")
    args = parser.parse_args()

    if args.local:
        if not run_prerequisites_checks():
            log_result("Erro nos pré-requisitos. Abortando instalação.", "fail")
            return
        install_pihole()
        install_suricata()
        install_wazuh_agent()
        install_kibana()
        save_report()
    else:
        print(colored("Use a flag --local para executar a instalação local.", "yellow"))

if __name__ == "__main__":
    main()
