import paramiko

def execute_remote_command(host, user, password, command):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(host, username=user, password=password)

        stdin, stdout, stderr = ssh.exec_command(command)
        out = stdout.read().decode()
        err = stderr.read().decode()

        ssh.close()

        if err:
            return False, err.strip()
        return True, out.strip()

    except Exception as e:
        return False, str(e)
