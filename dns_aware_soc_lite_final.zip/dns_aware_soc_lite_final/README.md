
DNS-Aware SOC Lite

Instalador automatizado para uma arquitetura de segurança baseada em DNS.

Componentes:
- Pi-hole
- Suricata
- Wazuh
- Elasticsearch
- Kibana

Uso:
1. Instale dependências: Docker, Docker Compose, Python3
2. Execute: sudo python3 scripts/soc_installer.py --local
3. Suba os serviços: docker-compose up -d
