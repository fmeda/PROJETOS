#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

LOG_DIR="/var/log/kali_hardening"
GPG_PUBKEY_URL="https://example.com/publickey.gpg"
GPG_PUBKEY_PATH="/etc/kali_hardening/publickey.gpg"
HARDENING_SCRIPT="/usr/local/bin/kali_hardening.sh"

install_dependencies() {
    apt-get update
    apt-get install -y ufw auditd ssh curl gpg jq dialog
}

import_gpg_key() {
    mkdir -p /etc/kali_hardening
    curl -fsSL "$GPG_PUBKEY_URL" -o "$GPG_PUBKEY_PATH"
    gpg --import "$GPG_PUBKEY_PATH"
}

schedule_cron() {
    mkdir -p "$LOG_DIR"
    crontab -l 2>/dev/null | grep -v "$HARDENING_SCRIPT" > /tmp/crontab.tmp || true
    echo "0 2 * * * $HARDENING_SCRIPT --apply >> $LOG_DIR/cron.log 2>&1" >> /tmp/crontab.tmp
    crontab /tmp/crontab.tmp
    rm -f /tmp/crontab.tmp
}

case "${1:-}" in
    --install-all)
        install_dependencies
        import_gpg_key
        schedule_cron
        ;;
    --gpg)
        import_gpg_key
        ;;
    --cron)
        schedule_cron
        ;;
    *)
        echo "Uso: $0 [--install-all|--gpg|--cron]"
        exit 1
        ;;
esac
