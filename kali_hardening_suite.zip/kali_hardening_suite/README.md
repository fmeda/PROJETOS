# Kali Hardening Suite

Scripts profissionais para hardening avançado do Kali Linux alinhados com OWASP, NIST, CIS, MITRE ATT&CK e DevSecOps.

## Como usar

1. Dê permissão:
   ```bash
   chmod +x kali_hardening.sh bootstrap_installer.sh
