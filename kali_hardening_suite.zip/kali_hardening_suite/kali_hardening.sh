#!/bin/bash
#
# kali_hardening.sh - Hardening avançado para Kali Linux
# Alinhado com OWASP, NIST, CIS, MITRE, DevSecOps e Hardening militarizado
#
# Autor: Seu Nome
# Versão: 1.0
# Data: 2025-06-25
#
set -euo pipefail
IFS=$'\n\t'

readonly LOG_DIR="/var/log/kali_hardening"
readonly ROLLBACK_FILE="$LOG_DIR/rollback.sh"
readonly TELEMETRY_FILE="$LOG_DIR/telemetry.log"
readonly SLACK_WEBHOOK_URL="https://hooks.slack.com/services/SEU/WEBHOOK/AQUI"
readonly GPG_PUBKEY_PATH="/etc/kali_hardening/publickey.gpg"
readonly SCRIPT_SIGNATURE="kali_hardening.sh.sig"

# ================== UTILITÁRIOS ==================

log() {
    local level="$1"
    local message="$2"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$level] $message" | tee -a "$LOG_DIR/hardening.log"
}

error_exit() {
    log "ERROR" "$1"
    exit 1
}

backup_command() {
    echo "$1" >> "$ROLLBACK_FILE"
}

validate_gpg_signature() {
    if ! command -v gpg &>/dev/null; then
        error_exit "gpg não encontrado, instale antes de executar."
    fi

    if ! gpg --verify "$SCRIPT_SIGNATURE" ./kali_hardening.sh &>/dev/null; then
        error_exit "Falha na validação da assinatura GPG do script."
    fi

    log "INFO" "Assinatura GPG validada com sucesso."
}

register_telemetry() {
    local user host timestamp
    user=$(whoami)
    host=$(hostname)
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "{\"user\": \"$user\", \"host\": \"$host\", \"timestamp\": \"$timestamp\"}" >> "$TELEMETRY_FILE"
}

notify_slack() {
    local message="$1"
    if command -v curl &>/dev/null; then
        curl -s -X POST -H 'Content-type: application/json' \
            --data "{\"text\":\"$message\"}" "$SLACK_WEBHOOK_URL" >/dev/null 2>&1
    fi
}

# ================== HARDENING ==================

apply_selinux_enforcing() {
    log "INFO" "Configurando SELinux em modo enforcing."
    if sestatus &>/dev/null; then
        sudo setenforce 1 || backup_command "setenforce 0"
        sed -i 's/^SELINUX=.*/SELINUX=enforcing/' /etc/selinux/config
    else
        log "WARN" "SELinux não instalado ou não ativo."
    fi
}

configure_firewall() {
    log "INFO" "Configurando firewall UFW (Uncomplicated Firewall)."
    if ! command -v ufw &>/dev/null; then
        error_exit "ufw não instalado. Instale antes de executar."
    fi

    ufw default deny incoming
    ufw default allow outgoing
    ufw allow ssh
    ufw enable
    backup_command "ufw disable"
}

harden_sshd() {
    log "INFO" "Aplicando hardening no SSHD."
    local sshd_config="/etc/ssh/sshd_config"
    cp "$sshd_config" "${sshd_config}.bak"
    backup_command "mv ${sshd_config}.bak $sshd_config"

    sed -i 's/^#PermitRootLogin.*/PermitRootLogin no/' "$sshd_config"
    sed -i 's/^#PasswordAuthentication.*/PasswordAuthentication no/' "$sshd_config"
    sed -i 's/^#X11Forwarding.*/X11Forwarding no/' "$sshd_config"
    systemctl restart sshd
}

install_and_configure_auditd() {
    log "INFO" "Instalando e configurando auditd."
    if ! command -v auditctl &>/dev/null; then
        apt-get update && apt-get install -y auditd || error_exit "Falha ao instalar auditd."
    fi

    systemctl enable auditd
    systemctl start auditd
    auditctl -e 1
    backup_command "auditctl -e 0"
}

apply_banner_legal() {
    log "INFO" "Aplicando banner legal conforme DISA STIG e NIST."
    local banner_file="/etc/issue.net"
    echo "Aviso: Acesso autorizado apenas a usuários autorizados. Todas as ações são monitoradas." > "$banner_file"
    sed -i 's/^#Banner none/Banner \/etc\/issue.net/' /etc/ssh/sshd_config
    systemctl reload sshd
    backup_command "sed -i 's/^Banner \/etc\/issue.net/#Banner none/' /etc/ssh/sshd_config"
}

remove_unnecessary_packages() {
    log "INFO" "Removendo pacotes inseguros."
    local packages=("telnet" "rsh-client" "nis" "ypbind")
    for pkg in "${packages[@]}"; do
        if dpkg -l | grep -q "$pkg"; then
            apt-get purge -y "$pkg"
            backup_command "apt-get install -y $pkg"
        fi
    done
}

# ================== PENTEST TOOLS CHECK ==================

verificar_pentest_tools() {
    log "INFO" "Verificando ferramentas de pentest e exibindo parâmetros comuns."

    declare -A tools_params=(
        [nmap]="Ex: nmap -sS -p 1-65535 -T4 target.com"
        [recon-ng]="Uso: recon-ng -w workspace; módulos: marketplace search, modules load"
        [theharvester]="theharvester -d domain.com -b google"
        [msfconsole]="msfconsole; use exploit, set payload, run"
        [searchsploit]="searchsploit termo"
        [sqlmap]="sqlmap -u 'http://site.com/page.php?id=1' --batch --dbs"
        [nikto]="nikto -h http://site.com"
        [wpscan]="wpscan --url http://site.com --enumerate u"
        [hydra]="hydra -l user -P passlist.txt ssh://target"
        [john]="john --wordlist=rockyou.txt hashfile"
        [responder]="responder -I eth0"
        [impacket-smbclient]="smbclient.py TARGET -u user -p pass"
        [bloodhound]="bloodhound -u user -p pass -d domain"
        [wireshark]="wireshark &"
        [ettercap]="ettercap -T -q -i eth0 -M arp /target1/ /target2/"
        [bettercap]="bettercap -iface eth0"
        [tcpdump]="tcpdump -i eth0 -w capture.pcap"
        [burpsuite]="burpsuite (GUI)"
        [zaproxy]="zap.sh (GUI)"
        [setoolkit]="setoolkit (menu interativo)"
    )

    local missing_tools=()

    for tool in "${!tools_params[@]}"; do
        if ! command -v "$tool" &>/dev/null; then
            missing_tools+=("$tool")
        else
            echo -e "\n[OK] $tool encontrado."
            echo "    Parâmetros comuns: ${tools_params[$tool]}"
        fi
    done

    if [ ${#missing_tools[@]} -gt 0 ]; then
        log "WARN" "Ferramentas pentest faltando: ${missing_tools[*]}"
        echo "Recomenda-se instalar: sudo apt install <nome_pacote>"
    fi
}

# ================== MAIN ==================

main() {
    mkdir -p "$LOG_DIR"

    # Validar assinatura do script
    validate_gpg_signature

    # Registrar telemetria
    register_telemetry

    # Aplicar hardening
    apply_selinux_enforcing
    configure_firewall
    harden_sshd
    install_and_configure_auditd
    apply_banner_legal
    remove_unnecessary_packages

    # Notificar equipe via Slack
    notify_slack "Hardening Kali Linux executado em $(hostname) por $(whoami)."

    log "INFO" "Hardening finalizado com sucesso."
}

# ================== CLI INTERFACE ==================

case "${1:-}" in
    --apply)
        main
        ;;
    --check-pentest)
        verificar_pentest_tools
        ;;
    *)
        echo "Uso: $0 {--apply|--check-pentest}"
        exit 1
        ;;
esac

exit 0
