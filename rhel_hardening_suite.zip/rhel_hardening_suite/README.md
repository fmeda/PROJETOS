# RHEL Hardening Suite

Scripts profissionais para endurecimento de servidores Red Hat Linux seguindo padrões CIS, STIG, NIST e DevSecOps.

## Conteúdo
- `rhel_hardening.sh`: Script principal de hardening (v3.0)
- `bootstrap_installer.sh`: Instalador de dependências, chave GPG e agendamento via cron
- `publickey.gpg`: Chave pública para validação da assinatura digital
- `.github/workflows`: Pipeline para escaneamento de segurança CI/CD

## Como usar
1. Torne os scripts executáveis:
   ```bash
   chmod +x rhel_hardening.sh bootstrap_installer.sh
