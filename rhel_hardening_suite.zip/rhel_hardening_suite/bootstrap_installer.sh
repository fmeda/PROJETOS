#!/bin/bash
# Script: bootstrap_installer.sh
# Objetivo: Instalar dependências, importar chave GPG, agendar cron para rhel_hardening.sh

set -euo pipefail
IFS=$'\n\t'

HARDENING_SCRIPT="/usr/local/bin/rhel_hardening.sh"
GPG_PUBKEY_URL="https://example.com/publickey.gpg"
GPG_DEST="/etc/hardening/publickey.gpg"
LOG_DIR="/var/log/hardening"

install_dependencies() {
    echo "[+] Instalando pacotes necessários..."
    dnf install -y jq dialog gpg curl audit policycoreutils firewalld openssh-server
}

importar_gpg() {
    echo "[+] Importando chave GPG pública..."
    mkdir -p /etc/hardening
    curl -fsSL "$GPG_PUBKEY_URL" -o "$GPG_DEST"
    gpg --import "$GPG_DEST"
}

agendar_cron() {
    echo "[+] Agendando execução diária do hardening às 02:00 via cron..."
    mkdir -p "$LOG_DIR"
    crontab -l 2>/dev/null | grep -v rhel_hardening.sh > /tmp/crontab.tmp || true
    echo "0 2 * * * $HARDENING_SCRIPT --apply >> $LOG_DIR/cron_exec.log 2>&1" >> /tmp/crontab.tmp
    crontab /tmp/crontab.tmp && rm -f /tmp/crontab.tmp
}

case "${1:-}" in
    --install-all)
        install_dependencies
        importar_gpg
        agendar_cron
        ;;
    --gpg)
        importar_gpg
        ;;
    --cron)
        agendar_cron
        ;;
    *)
        echo "Uso: $0 [--cron | --gpg | --install-all]"
        exit 1
        ;;
esac
