import subprocess
import sys

required = [
    "fastapi",
    "uvicorn[standard]",
    "python-nmap",
    "PyJWT",
    "pydantic",
    "requests",
    "pytest"
]

def install_package(pkg):
    print(f"Instalando pacote: {pkg} ...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])

def check_and_install():
    for pkg in required:
        try:
            __import__(pkg.split('[')[0])
            print(f"Pacote {pkg} já instalado.")
        except ImportError:
            install_package(pkg)

if __name__ == "__main__":
    check_and_install()
