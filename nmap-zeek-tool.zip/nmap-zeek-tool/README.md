# 🛡️ Nmap+Zeek Recon API - Produção Hardened

Uma API robusta e segura para varredura ativa com Nmap e análise passiva de tráfego com Zeek. Ideal para uso em ambientes corporativos, SIEM/SOAR e times de Cyber Defesa.

---

## 🚀 Funcionalidades

- ✅ Scanner ativo com Nmap (`sS`, `T4`)
- ✅ Parser inteligente de logs Zeek (JSON)
- ✅ Autenticação JWT
- ✅ Validação de entradas (Pydantic)
- ✅ Pronto para produção com Docker
- ✅ Testes automatizados com Pytest
- ✅ Integração futura com Wazuh, ELK, Graylog
- ✅ Pronto para APIs externas (SOAR, Zabbix, etc.)

---

## ⚙️ Instalação

### Pré-requisitos

- Python 3.10+
- Zeek configurado para gerar `conn.log` em JSON
- Variáveis ambiente:

```bash
export JWT_SECRET="superseguro123"
export ZEKE_LOG_PATH="/var/log/zeek/conn.json"
export ALLOWED_ORIGINS="https://minhaempresa.com"
