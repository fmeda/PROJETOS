import subprocess
import sys
import importlib
import os
import secrets
import logging
import json
import ipaddress
from datetime import datetime, timedelta
from typing import Optional

from fastapi import FastAPI, HTTPException, Depends, status, Request, Security
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, field_validator
from dotenv import load_dotenv
import jwt
import nmap

# === 1. Verificar e instalar pacotes necessários automaticamente ===
required_packages = [
    "fastapi",
    "uvicorn",
    "python-multipart",
    "pydantic",
    "python-dotenv",
    "pyjwt",
    "nmap",
]

def check_and_install_packages(packages):
    for package in packages:
        try:
            module_name = package
            if package == "pyjwt":
                module_name = "jwt"
            elif package == "python-dotenv":
                module_name = "dotenv"
            elif package == "python-multipart":
                module_name = "multipart"
            importlib.import_module(module_name)
        except ImportError:
            print(f"Pacote '{package}' não encontrado. Tentando instalar com --user...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "--user", package])
            except subprocess.CalledProcessError as e:
                print(f"Erro ao instalar pacote '{package}': {e}")
                print(f"Por favor, instale manualmente executando:\npython -m pip install --user {package}")
                sys.exit(1)

check_and_install_packages(required_packages)

# === 2. Importar novamente (para garantir) após possível instalação ===
import jwt
import nmap
from fastapi import FastAPI, HTTPException, Depends, status, Request, Security
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, field_validator
from dotenv import load_dotenv

# === 3. Configurações iniciais e logger ===
load_dotenv()  # Carrega .env

logger = logging.getLogger("nmap_zeek_tool")
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

# === 4. Configurar JWT_SECRET com persistência em arquivo para dev ===
JWT_SECRET = os.getenv("JWT_SECRET")
JWT_SECRET_FILE = ".jwt_secret"

def get_jwt_secret():
    global JWT_SECRET
    if JWT_SECRET:
        return JWT_SECRET

    if os.path.isfile(JWT_SECRET_FILE):
        with open(JWT_SECRET_FILE, "r") as f:
            secret = f.read().strip()
            if secret:
                logger.warning("JWT_SECRET não definido no ambiente, usando segredo temporário persistente (modo DEV). Configure JWT_SECRET para produção.")
                return secret

    secret = secrets.token_urlsafe(64)
    with open(JWT_SECRET_FILE, "w") as f:
        f.write(secret)
    logger.warning("JWT_SECRET não definido no ambiente, gerando segredo temporário persistente (modo DEV). Configure JWT_SECRET para produção.")
    return secret

JWT_SECRET = get_jwt_secret()
JWT_ALGORITHM = "HS256"
JWT_ACCESS_TOKEN_EXPIRE_MINUTES = 30

ZEKE_LOG_PATH = os.getenv("ZEKE_LOG_PATH", "/var/log/zeek/conn.json")

# === 5. Inicializar FastAPI e CORS ===
app = FastAPI(title="Nmap+Zeek Recon API")

origins = os.getenv("ALLOWED_ORIGINS", "http://localhost").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# === 6. Modelos Pydantic com validadores Pydantic v2 ===
class ScanRequest(BaseModel):
    target: str
    ports: Optional[str] = None

    @field_validator("target")
    def valid_ip(cls, v):
        try:
            ipaddress.ip_network(v, strict=False)
            return v
        except ValueError:
            raise ValueError("target deve ser um IP ou range válido")

    @field_validator("ports")
    def valid_ports(cls, v):
        if v is None:
            return v
        import re
        pattern = re.compile(r'^(\d+(-\d+)?)(,(\d+(-\d+)?))*$')
        if not pattern.match(v):
            raise ValueError("ports deve ser números separados por vírgula ou ranges (ex: 22,80,443-445)")
        return v

class Token(BaseModel):
    access_token: str
    token_type: str

class ScanResult(BaseModel):
    scan_data: dict
    zeek_summary: dict

# === 7. Usuários fake para autenticação (substituir por real) ===
fake_users_db = {
    "analista": {
        "username": "analista",
        "full_name": "Analista Segurança",
        "hashed_password": "fakehashedsecret",
        "disabled": False,
    }
}

def verify_password(plain_password, hashed_password):
    # Implementar hash seguro na prática; aqui é só exemplo
    return plain_password == "secret" and hashed_password == "fakehashedsecret"

def get_user(db, username: str):
    return db.get(username)

def authenticate_user(db, username: str, password: str):
    user = get_user(db, username)
    if not user or not verify_password(password, user["hashed_password"]):
        return False
    return user

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=JWT_ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return encoded_jwt

async def get_current_user(token: str = Security(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Não autorizado",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except jwt.PyJWTError:
        raise credentials_exception
    user = get_user(fake_users_db, username)
    if user is None or user.get("disabled"):
        raise HTTPException(status_code=400, detail="Usuário inválido ou desativado")
    return user

# === 8. Funções principais ===
def run_nmap_scan(target: str, ports: Optional[str] = None) -> dict:
    nm = nmap.PortScanner()
    args = "-sS -T4"
    logger.info(f"Nmap scan: target={target} ports={ports or 'default'}")
    result = nm.scan(hosts=target, ports=ports, arguments=args) if ports else nm.scan(hosts=target, arguments=args)
    return result

def parse_zeek_log(path: str):
    if not os.path.isfile(path):
        logger.warning(f"Zeek log não encontrado: {path}")
        return []
    with open(path, "r") as f:
        lines = [json.loads(line) for line in f if line.strip() and not line.startswith("#")]
    return lines

def summarize_zeek_logs(logs):
    suspicious = sum(1 for l in logs if l.get("id.resp_p") == 23)
    unique_ips = len(set(l.get("id.orig_h") for l in logs if l.get("id.orig_h")))
    return {
        "total_logs": len(logs),
        "unique_ips": unique_ips,
        "suspected_telnet_connections": suspicious,
    }

# === 9. Endpoints ===
@app.post("/token", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = authenticate_user(fake_users_db, form_data.username, form_data.password)
    if not user:
        logger.warning(f"Login falhou: {form_data.username}")
        raise HTTPException(status_code=400, detail="Usuário ou senha incorretos")
    access_token = create_access_token(data={"sub": user["username"]})
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/scan", response_model=ScanResult)
async def perform_scan(scan_request: ScanRequest, user: dict = Depends(get_current_user), request: Request = None):
    client_ip = request.client.host if request else "desconhecido"
    logger.info(f"Usuário {user['username']} iniciou varredura: {scan_request.target} IP: {client_ip}")
    try:
        scan_data = run_nmap_scan(scan_request.target, scan_request.ports)
        zeek_logs = parse_zeek_log(ZEKE_LOG_PATH)
        zeek_summary = summarize_zeek_logs(zeek_logs)
        return ScanResult(scan_data=scan_data, zeek_summary=zeek_summary)
    except Exception as e:
        logger.error(f"Erro na varredura: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/")
async def root():
    return {"message": "API Nmap+Zeek funcionando. Use /docs para acessar Swagger UI"}
