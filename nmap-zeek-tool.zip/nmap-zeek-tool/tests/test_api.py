import pytest
from fastapi.testclient import TestClient
from app.main import app, create_access_token

client = TestClient(app)

@pytest.fixture
def token():
    return create_access_token({"sub": "analista"})

def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert "message" in response.json()

def test_token_success():
    response = client.post("/token", data={"username": "analista", "password": "secret"})
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"

def test_token_fail():
    response = client.post("/token", data={"username": "analista", "password": "wrong"})
    assert response.status_code == 400

def test_scan_unauthorized():
    response = client.post("/scan", json={"target": "127.0.0.1"})
    assert response.status_code == 401

def test_scan_authorized(token):
    headers = {"Authorization": f"Bearer {token}"}
    response = client.post("/scan", json={"target": "127.0.0.1"}, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "scan_data" in data
    assert "zeek_summary" in data
