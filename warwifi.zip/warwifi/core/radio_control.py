"""
radio_control.py - Controle de rádio: potência e beacon hopping
"""

import os
import random
import time
import logging

def beacon_hop(interface="wlan0"):
    logging.info("[RADIO] Iniciando beacon hopping")
    try:
        while True:
            channel = random.randint(1, 11)
            os.system(f"iwconfig {interface} channel {channel}")
            logging.info(f"[RADIO] Canal alterado para: {channel}")
            time.sleep(20)
    except KeyboardInterrupt:
        logging.info("[RADIO] Beacon hopping interrompido pelo usuário")

def set_tx_power(interface="wlan0", level="medium"):
    power_levels = {"low": 5, "medium": 15, "high": 20}
    power = power_levels.get(level, 15)
    os.system(f"iwconfig {interface} txpower {power}")
    logging.info(f"[RADIO] Potência de transmissão definida para: {power} dBm")
