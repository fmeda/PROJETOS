"""
credential_guard.py - Proteção de segredos com Vault
"""

import hvac
import os
import logging

def connect_to_vault():
    try:
        client = hvac.Client(url='http://127.0.0.1:8200')
        client.token = os.getenv("VAULT_TOKEN")
        if not client.is_authenticated():
            raise Exception("Autenticação no Vault falhou")
        return client
    except Exception as e:
        logging.critical(f"[VAULT] Falha ao conectar: {e}")
        return None

def get_secret(path):
    client = connect_to_vault()
    if client:
        try:
            secret = client.secrets.kv.read_secret_version(path=path)
            return secret['data']['data']
        except Exception as e:
            logging.error(f"[VAULT] Erro ao ler segredo: {e}")
    return {}
