"""
monitor.py - Módulo de monitoramento WIDS via Kismet e Snort
"""

import logging
import os

def monitor_kismet_logs(log_file="/var/log/kismet/kismet_alerts.log"):
    if not os.path.exists(log_file):
        logging.warning(f"[WIDS] Log não encontrado: {log_file}")
        return
    try:
        with open(log_file, 'r') as f:
            for line in f:
                if "DEAUTH" in line or "BSSID spoof" in line:
                    logging.warning(f"[WIDS ALERTA] {line.strip()}")
    except Exception as e:
        logging.error(f"[WIDS] Erro ao ler log: {e}")
