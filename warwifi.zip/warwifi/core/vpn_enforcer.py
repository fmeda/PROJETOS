"""
vpn_enforcer.py - Exige conexão VPN ativa (WireGuard)
"""

import os
import logging

def check_vpn(interface="wg0"):
    route = os.popen("ip route show default").read()
    if interface not in route:
        logging.critical("[VPN] Túnel VPN inativo - Desativando Wi-Fi!")
        os.system("nmcli radio wifi off")
        return False
    logging.info("[VPN] Túnel ativo verificado.")
    return True
