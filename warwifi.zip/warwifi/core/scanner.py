"""
scanner.py - Módulo de detecção de APs falsos (Evil Twin)
"""

import subprocess
import logging

def scan_wifi_interfaces(interface="wlan0"):
    try:
        result = subprocess.check_output(['iwlist', interface, 'scanning'], stderr=subprocess.DEVNULL)
        return result.decode('utf-8')
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao escanear interfaces Wi-Fi: {e}")
        return ""

def detect_evil_twin(ssid):
    scan_result = scan_wifi_interfaces()
    if scan_result.count(f'ESSID:"{ssid}"') > 1:
        logging.warning(f"[!] Possível AP falso detectado: {ssid}")
        return True
    return False
