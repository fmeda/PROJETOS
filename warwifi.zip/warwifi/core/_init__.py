"""
Inicializador do módulo core do WARWIFI.
"""
