"""
main.py - CLI principal do WARWIFI
"""

import sys
import logging
from menu import show_menu  # Correto se você executar dentro de cli/: python main.py
# Se executar via: python -m cli.main — use: from cli.menu import show_menu

# Importações opcionais do core (ajustar se desejar funcionalidade integrada)
# from core import scanner, monitor, vpn_enforcer, radio_control

def main():
    logging.basicConfig(level=logging.INFO, format='[%(levelname)s] %(message)s')
    print("=== WARWIFI - Wireless Combat Shield ===")

    while True:
        try:
            choice = show_menu()

            if choice == '1':
                print("[*] Iniciando scanner de APs falsos...")
                # scanner.detect_evil_twin("EmpresaSegura")  # Descomente se estiver implementado

            elif choice == '2':
                print("[*] Ativando monitor WIDS...")
                # monitor.monitor_kismet_logs()

            elif choice == '3':
                print("[*] Verificando VPN...")
                # vpn_enforcer.check_vpn()

            elif choice == '4':
                print("[*] Iniciando beacon hopping...")
                # radio_control.beacon_hop()

            elif choice == '0':
                print("[*] Saindo...")
                break

            else:
                print("[!] Opção inválida. Tente novamente.")

        except KeyboardInterrupt:
            print("\n[!] Execução interrompida pelo usuário.")
            sys.exit(0)

        except Exception as e:
            logging.error(f"[ERRO] Falha durante execução: {e}")

if __name__ == '__main__':
    main()
