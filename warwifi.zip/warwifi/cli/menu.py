"""
menu.py - Menu interativo para CLI WARWIFI
"""

def show_menu():
    print("""
[1] Scanner de APs falsos (Evil Twin)
[2] Monitor WIDS (Kismet/Snort)
[3] Verificar VPN (WireGuard)
[4] Beacon hopping e controle de rádio
[0] Sair
""")
    choice = input("Escolha uma opção: ")
    return choice.strip()
