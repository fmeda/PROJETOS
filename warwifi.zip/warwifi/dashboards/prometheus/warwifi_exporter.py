from prometheus_client import start_http_server, Gauge
import random
import time

# Métricas
deauth_packets = Gauge('warwifi_deauth_packets', 'Pacotes de deautenticação detectados')
vpn_status = Gauge('warwifi_vpn_active', 'Status da VPN (1=ativa, 0=inativa)')
interference_level = Gauge('warwifi_interference_level', 'Nível de interferência detectada')
beacon_hop_channel = Gauge('warwifi_beacon_channel', 'Canal atual do beacon hopping')

def collect_metrics():
    while True:
        deauth_packets.set(random.randint(0, 50))        # Simulação
        vpn_status.set(1)                                 # VPN ativa
        interference_level.set(random.uniform(0.0, 1.0))  # Nível 0 a 1
        beacon_hop_channel.set(random.randint(1, 11))     # Canal atual
        time.sleep(10)

if __name__ == "__main__":
    print("[+] Exportador Prometheus WARWIFI iniciado em :8080")
    start_http_server(8080)
    collect_metrics()
