# WARWIFI - Wireless Combat Shield

**WARWIFI** é uma solução tática para defesa de redes Wi-Fi empresariais e militares.

## Funcionalidades
- Detecção de APs falsos (Evil Twin)
- VPN Always-On para tráfego Wi-Fi
- Geofencing + beacon hopping
- WIDS com Snort e Kismet
- Integração com Vault para segredos

## Instalação
```bash
git clone https://github.com/warwifi/warwifi.git
cd warwifi
bash scripts/deploy.sh
