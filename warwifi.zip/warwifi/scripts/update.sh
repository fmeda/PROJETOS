#!/bin/bash
echo "[+] Atualizando WARWIFI..."
apt update && apt upgrade -y

echo "[+] Atualizando dependências Python..."
pip3 install --upgrade -r requirements.txt

echo "[+] Reiniciando serviços..."
systemctl restart hostapd freeradius snort

echo "[+] Atualização concluída."
