#!/bin/bash
echo "[+] Instalando dependências..."
apt update && apt install -y hostapd freeradius snort wireguard python3-pip

echo "[+] Instalando dependências Python..."
pip3 install -r requirements.txt

echo "[+] Inicializando serviços..."
systemctl enable hostapd
systemctl restart hostapd

systemctl enable freeradius
systemctl restart freeradius

systemctl enable snort
systemctl restart snort

echo "[+] WARWIFI instalado e serviços iniciados."
