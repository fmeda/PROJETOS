from setuptools import setup, find_packages

setup(
    name="warwifi",
    version="1.0.0",
    description="WARWIFI - Wireless Combat Shield",
    author="Equipe WARWIFI",
    author_email="contato@warwifi.def",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "hvac",
        "prometheus_client"
    ],
    entry_points={
        "console_scripts": [
            "warwifi=cli.main:main"
        ]
    },
)
