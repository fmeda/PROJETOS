from core import monitor
import tempfile

def test_monitor_log_detection():
    log = tempfile.NamedTemporaryFile(delete=False, mode="w+")
    log.write("2024 DEAUTH detected\n")
    log.seek(0)
    monitor.monitor_kismet_logs(log.name)
    log.close()
