from core import vpn_enforcer
import os

def test_vpn_check(monkeypatch):
    monkeypatch.setattr(os, "popen", lambda x: iter(["default dev wg0"]))
    assert vpn_enforcer.check_vpn() == True
