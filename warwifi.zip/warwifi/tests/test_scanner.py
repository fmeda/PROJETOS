from core import scanner

def test_evil_twin_detection(monkeypatch):
    def fake_scan():
        return 'ESSID:"Empresa1"\nESSID:"Empresa1"'
    monkeypatch.setattr(scanner, "scan_wifi_interfaces", fake_scan)
    assert scanner.detect_evil_twin("Empresa1") == True
