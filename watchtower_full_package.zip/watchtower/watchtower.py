#!/usr/bin/env python3
import typer
from modules import memory, disk, net, events
from reporter import generate_report
from security import validate_token
from config import load_config

app = typer.Typer()

@app.command()
def full(target: str):
    config = load_config()
    memory.collect(target)
    disk.collect(target)
    net.capture(target)
    events.fetch(target)
    typer.echo("Coleta completa finalizada.")

@app.command()
def report(format: str = "pdf", encrypt: bool = True):
    generate_report(format=format, encrypt=encrypt)

@app.command()
def validate(token: str):
    valid = validate_token(token)
    typer.echo("Token válido." if valid else "Token inválido.")

if __name__ == "__main__":
    app()
