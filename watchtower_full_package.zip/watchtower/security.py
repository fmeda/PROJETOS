import hashlib

def validate_token(token: str) -> bool:
    expected_hash = "SHA256DoTokenDeAcesso"
    return hashlib.sha256(token.encode()).hexdigest() == expected_hash
