import os
from dotenv import load_dotenv

def load_config():
    load_dotenv(os.path.expanduser("~/.watchtower.env"))
    return {
        "VOLATILITY_PROFILE": os.getenv("VOLATILITY_PROFILE"),
        "FTP_HOST": os.getenv("FTP_HOST"),
        "FTP_USER": os.getenv("FTP_USER"),
        "FTP_PASS": os.getenv("FTP_PASS"),
    }
