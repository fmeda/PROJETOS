def collect(target): print(f'Coletando disco de {target}')
