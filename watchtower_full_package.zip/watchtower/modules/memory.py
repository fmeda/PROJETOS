def collect(target): print(f'Coletando memória de {target}')
