def fetch(target): print(f'Coletando eventos de {target}')
