def capture(target): print(f'Capturando tráfego de {target}')
