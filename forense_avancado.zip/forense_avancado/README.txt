Análise Forense Avançada - Pacote de Scripts
=============================================

Propósito:
----------
Este pacote contém scripts para análise forense avançada de imagens de memória RAM e disco rígido,
integrando ferramentas profissionais como Volatility3 e Plaso, com registro seguro em banco de dados SQLite
e consulta automática à API do VirusTotal para detecção de ameaças.

Tecnologias Utilizadas:
-----------------------
- Python 3.8+
- Volatility3
- Plaso (log2timeline.py, psort.py)
- SQLite3 para registro dos casos
- API VirusTotal (consulta via requests)
- Logging avançado para auditoria e rastreabilidade

Pré-requisitos:
---------------
- Python 3 instalado
- Ferramentas externas instaladas e disponíveis no PATH:
    - volatility3
    - log2timeline.py
    - psort.py
- Variável de ambiente VT_API_KEY configurada com sua chave da API VirusTotal
- Permissões para criar arquivos e pastas no diretório de execução

Configuração:
-------------
1. Certifique-se que as ferramentas externas estejam instaladas e no PATH.
2. Configure a variável de ambiente VT_API_KEY com sua chave da VirusTotal API.
3. Garanta que o Python 3 está instalado e atualizado.
4. Instale os pacotes Python necessários (requests) — o script tentará instalar automaticamente se faltar.

Exemplo de Execução:
--------------------
No prompt de comando, execute:

python forense_avancado.py memory.raw disco.E01 --analista "Seu Nome" --output resultados

Onde:
- memory.raw: arquivo de imagem da memória RAM a ser analisada.
- disco.E01: arquivo de imagem do disco rígido.
- --analista: nome do analista responsável pela investigação.
- --output: (opcional) diretório onde os resultados e logs serão salvos. Padrão é "output".

Contato do Autor:
-----------------
Fabiano Aparecido  
Email: fabiano.aparecido@example.com  
LinkedIn: https://www.linkedin.com/in/fabianoaparecido/  

---

