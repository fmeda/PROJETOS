#!/usr/bin/env python3
"""
Script de Análise Forense Avançada - Produção
Autor: Fabiano Aparecido
Descrição: Análise de memória e disco com Volatility3 e Plaso,
registrando evidências, logs auditáveis, e integração VirusTotal real.
"""

import argparse
import subprocess
import hashlib
import sqlite3
import logging
import os
import sys
import shutil
from datetime import datetime
from pathlib import Path
import importlib.util

def install_package(package: str) -> None:
    """Instala pacote Python via pip."""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
    except subprocess.CalledProcessError as e:
        print(f"Erro ao instalar o pacote {package}: {e}")
        sys.exit(1)

def ensure_packages() -> None:
    """Garante instalação dos pacotes Python necessários."""
    required = ["requests"]

    for pkg in required:
        if importlib.util.find_spec(pkg) is None:
            print(f"Pacote {pkg} não encontrado. Instalando...")
            install_package(pkg)
        else:
            print(f"Pacote {pkg} já instalado.")

ensure_packages()
import requests

DB_PATH = Path("dados/casos.db")
LOG_PATH = Path("dados/execucao.log")

# Cria diretório de logs caso não exista
LOG_PATH.parent.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    filename=LOG_PATH,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

VT_API_KEY = os.getenv("VT_API_KEY")

def check_tools_exist(tools: list[str]) -> None:
    """Verifica se as ferramentas externas estão instaladas e acessíveis."""
    missing = [tool for tool in tools if not shutil.which(tool)]
    if missing:
        logging.error(f"Ferramentas ausentes: {', '.join(missing)}")
        print(f"Erro: as seguintes ferramentas não foram encontradas: {', '.join(missing)}")
        sys.exit(1)

def sha256sum(file_path: Path) -> str:
    """Calcula hash SHA256 de um arquivo."""
    h = hashlib.sha256()
    try:
        with file_path.open('rb') as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
    except FileNotFoundError:
        logging.error(f"Arquivo não encontrado para hash: {file_path}")
        print(f"Erro: arquivo não encontrado: {file_path}")
        sys.exit(1)
    except Exception as e:
        logging.error(f"Erro ao calcular hash: {e}")
        print(f"Erro ao calcular hash do arquivo {file_path}: {e}")
        sys.exit(1)
    return h.hexdigest()

def setup_db() -> None:
    """Configura o banco de dados SQLite para registro dos casos."""
    try:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS casos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                data TEXT,
                analista TEXT,
                hash_mem TEXT,
                hash_disco TEXT,
                ferramenta TEXT,
                saida TEXT
            )
        """)
        conn.commit()
        conn.close()
    except Exception as e:
        logging.error(f"Erro ao configurar banco de dados: {e}")
        print(f"Erro ao configurar banco de dados: {e}")
        sys.exit(1)

def registrar_caso(analista: str, hash_mem: str, hash_disco: str, ferramenta: str, saida: str) -> None:
    """Registra um caso no banco de dados SQLite."""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO casos (data, analista, hash_mem, hash_disco, ferramenta, saida)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (datetime.now().isoformat(), analista, hash_mem, hash_disco, ferramenta, saida))
        conn.commit()
        conn.close()
    except Exception as e:
        logging.error(f"Erro ao registrar caso no banco: {e}")
        print(f"Erro ao registrar caso no banco: {e}")

def executar_comando(cmd: list[str], output_file: Path) -> None:
    """Executa comando shell e grava saída em arquivo."""
    try:
        with output_file.open("w") as f:
            subprocess.run(cmd, stdout=f, stderr=subprocess.PIPE, check=True)
    except subprocess.CalledProcessError as e:
        stderr_msg = e.stderr.decode().strip() if e.stderr else "Sem mensagem de erro"
        logging.error(f"Erro na execução do comando {' '.join(cmd)}: {stderr_msg}")
        print(f"Erro ao executar comando: {' '.join(cmd)}\n{stderr_msg}")
        sys.exit(1)
    except Exception as e:
        logging.error(f"Erro inesperado ao executar comando {' '.join(cmd)}: {e}")
        print(f"Erro inesperado ao executar comando: {e}")
        sys.exit(1)

def run_volatility(mem_img: Path, out_dir: Path) -> None:
    """Executa plugins Volatility3 na imagem de memória."""
    plugins = ["windows.pslist.PsList", "windows.cmdline.CmdLine", "windows.filescan.FileScan"]
    for plugin in plugins:
        out_file = out_dir / f"{plugin.split('.')[-1].lower()}.txt"
        print(f"[Volatility] Executando plugin: {plugin}")
        executar_comando(["volatility3", "-f", str(mem_img), plugin], out_file)

def run_plaso(disk_img: Path, out_dir: Path) -> None:
    """Executa Plaso para timeline forense da imagem de disco."""
    dump_file = out_dir / "plaso.dump"
    timeline_file = out_dir / "timeline.csv"
    try:
        print("[Plaso] Criando dump de timeline...")
        subprocess.run(["log2timeline.py", str(dump_file), str(disk_img)], check=True, capture_output=True)
        print("[Plaso] Exportando timeline para CSV...")
        with timeline_file.open("w") as f:
            subprocess.run(["psort.py", "-o", "L2tcsv", str(dump_file)], stdout=f, check=True, capture_output=True)
    except subprocess.CalledProcessError as e:
        stderr_msg = e.stderr.decode().strip() if e.stderr else "Sem mensagem de erro"
        logging.error(f"Erro Plaso: {stderr_msg}")
        print(f"Erro na execução do Plaso: {stderr_msg}")
        sys.exit(1)
    except Exception as e:
        logging.error(f"Erro inesperado Plaso: {e}")
        print(f"Erro inesperado no Plaso: {e}")
        sys.exit(1)

def check_virustotal(hash_value: str) -> str:
    """Consulta VirusTotal para verificar hash."""
    if not VT_API_KEY:
        logging.warning("Chave API VirusTotal não configurada. Verificação ignorada.")
        return "API key VirusTotal não configurada"

    url = f"https://www.virustotal.com/api/v3/search?query={hash_value}"
    headers = {"x-apikey": VT_API_KEY}

    try:
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        data = response.json()
        if data.get("data"):
            positives = data["data"][0]["attributes"].get("last_analysis_stats", {}).get("malicious", 0)
            vt_link = f"https://www.virustotal.com/gui/search/{hash_value}"
            logging.info(f"VirusTotal: {positives} positivos para hash {hash_value}")
            return f"{vt_link} - {positives} positivos"
        else:
            logging.info(f"VirusTotal: Nenhum resultado para hash {hash_value}")
            return f"https://www.virustotal.com/gui/search/{hash_value} - Nenhum resultado"
    except requests.RequestException as e:
        logging.error(f"Erro na consulta VirusTotal: {e}")
        return f"Erro na consulta VirusTotal: {e}"

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Análise Forense Avançada - Ambiente Produção",
        usage="python forense_avancado.py mem_img disk_img --analista NOME_ANALISTA [--output DIRETORIO]"
    )
    parser.add_argument("mem_img", help="Imagem de memória RAM (ex: memory.raw)")
    parser.add_argument("disk_img", help="Imagem de disco (ex: disco.E01)")
    parser.add_argument("--analista", required=True, help="Nome do analista")
    parser.add_argument("--output", default="output", help="Diretório de saída")

    # Se nenhum argumento, exibe ajuda + exemplo e sai
    if len(sys.argv) == 1:
        print("Erro: parâmetros obrigatórios ausentes.\n")
        parser.print_help()
        print("\nExemplo de uso:")
        print("  python forense_avancado.py memory.raw disco.E01 --analista \"Fabiano Aparecido\" --output resultados")
        sys.exit(1)

    try:
        args = parser.parse_args()
    except SystemExit:
        print("\nExemplo de uso:")
        print("  python forense_avancado.py memory.raw disco.E01 --analista \"Fabiano Aparecido\" --output resultados")
        sys.exit(1)

    mem_img = Path(args.mem_img).resolve()
    disk_img = Path(args.disk_img).resolve()

    if not mem_img.is_file():
        print(f"Erro: arquivo de memória não encontrado: {mem_img}")
        sys.exit(1)
    if not disk_img.is_file():
        print(f"Erro: arquivo de disco não encontrado: {disk_img}")
        sys.exit(1)

    output = Path(args.output).resolve()
    vol_out = output / "volatility"
    plaso_out = output / "plaso"

    try:
        vol_out.mkdir(parents=True, exist_ok=True)
        plaso_out.mkdir(parents=True, exist_ok=True)
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        print(f"Erro ao criar diretórios: {e}")
        sys.exit(1)

    check_tools_exist(["volatility3", "log2timeline.py", "psort.py"])
    logging.info("Início da análise forense")
    setup_db()

    hash_mem = sha256sum(mem_img)
    hash_disco = sha256sum(disk_img)
    logging.info(f"Hash Memória: {hash_mem}")
    logging.info(f"Hash Disco: {hash_disco}")

    print("[+] Rodando Volatility...")
    run_volatility(mem_img, vol_out)
    registrar_caso(args.analista, hash_mem, hash_disco, "volatility3", str(vol_out))

    print("[+] Rodando Plaso...")
    run_plaso(disk_img, plaso_out)
    registrar_caso(args.analista, hash_mem, hash_disco, "plaso", str(plaso_out))

    print("[+] Verificando hashes no VirusTotal...")
    vt_mem = check_virustotal(hash_mem)
    vt_disco = check_virustotal(hash_disco)
    logging.info(f"VT memória: {vt_mem}")
    logging.info(f"VT disco: {vt_disco}")

    print("[✓] Análise forense concluída com sucesso.")
    print(f"[INFO] Resultados salvos em: {output}")

if __name__ == "__main__":
    main()
